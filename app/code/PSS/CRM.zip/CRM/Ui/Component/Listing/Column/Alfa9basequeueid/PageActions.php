<?php
/**
 * @author Cristian Sanclemente <csanclemente@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Ui\Component\Listing\Column\Alfa9basequeueid;

class PageActions extends \Magento\Ui\Component\Listing\Columns\Column
{
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource["data"]["items"])) {
            foreach ($dataSource["data"]["items"] as & $item) {
                $name = $this->getData("name");
                $id = "X";
                if(isset($item["alfa9_base_queue_id"]))
                {
                    $id = $item["alfa9_base_queue_id"];
                }
                $item[$name]["view"] = [
                    "href"=>$this->getContext()->getUrl(
                        "alfa9/queue/process",["alfa9_base_queue_id"=>$id]),
                    "label"=>__("Run now!")
                ];
            }
        }

        return $dataSource;
    }    
    
}
