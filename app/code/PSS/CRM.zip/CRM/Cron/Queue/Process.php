<?php
/**
 * @author Juan Carlos M. <juancarlos.martinez@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Cron\Queue;

use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Api\SearchCriteriaBuilder as Criteria;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Framework\ObjectManagerInterface;
use Alfa9\MDM\Helper\Data;
use Alfa9\Base\Api\QueueRepositoryInterface;

class Process {

    protected $_logger;
    protected $_scopeConfig;
    protected $_queueRepository;
    protected $_criteriaBuilder;
    protected $_sortOrderBuilder;
    protected $_objectManager;
    protected $_mdmHelper;
    protected $indexerFactory;

    public function __construct(
        LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        ObjectManagerInterface $objectManager,
        QueueRepositoryInterface $queueRepository,
        Criteria $criteriaBuilder,
        SortOrderBuilder $sortOrderBuilder,
        \Magento\Indexer\Model\IndexerFactory $indexerFactory,
        Data $mdmHelper
    ){
        $this->_logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->_objectManager = $objectManager;
        $this->_queueRepository = $queueRepository;
        $this->_criteriaBuilder = $criteriaBuilder;
        $this->_sortOrderBuilder = $sortOrderBuilder;
        $this->indexerFactory = $indexerFactory;
        $this->_mdmHelper = $mdmHelper;
        $this->indexerFactory = $indexerFactory;
    }

    public function execute()
    {

        error_reporting(-1);
        set_time_limit(0);

        $grouped=false;
        $configurables=false;


        //ESTE SCRIPT PROCESA LOS ELEMENTOS DE LA COLA DESDE EL CRON DE MAGENTO

        // if($this->_mdmHelper->getConfigProducts('enable_cron')==1) {

            if(!$grouped) {

                // PROCCESS GROUPED ITEMS FIRST

                $filter = $this->_criteriaBuilder
                    ->setPageSize(500)
                    ->addFilter('process_status', 'Pending', '=')
                    ->addFilter('method', 'group', '=')
                    ->create();

                $this->_logger->info('---------------------------------------------------');
                $this->_logger->info('Start process Queue (GROUPED): ' . date("Y-m-d H:i:s"));
                $this->_logger->info('---------------------------------------------------');

                $queueData = $this->_queueRepository->getList($filter)->getItems();
                foreach ($queueData as $product) {

                    $grouped = true;

                    if (isset($product['model'])) {

                        if (!@unserialize($product['data'])) {

                            $this->_logger->error('Error on queue product, unserialize error');
                            $this->_logger->error(json_encode($product));

                            $product->setData('process_status', "Error");
                            $product->setData('process_message', "Error on queue product, unserialize error");

                            $resp = $this->_queueRepository->save($product);

                        } else {

                            // Only process verified data
                            $data = unserialize($product['data']);
                            $processObject = $this->_objectManager->get($product['model']);
                            $processObject->{$product['method']}($data);

                            $this->_queueRepository->delete($product);

                            $this->_logger->info('Process product from Queue: ' . $product['process_name']);

                        }

                    } else {

                        $this->_logger->error('Error on queue product');
                        $this->_logger->error(json_encode($product));

                    }

                }

            }

            if(!$grouped){

                // PROCCESS CONFIGURABLES ITEMS AS SECOND INSTANCE

                $filter = $this->_criteriaBuilder
                    ->setPageSize(500)
                    ->addFilter('process_status', 'Pending', '=')
                    ->addFilter('method', 'configurable', '=')
                    ->create();

                $this->_logger->info('---------------------------------------------------');
                $this->_logger->info('Start process Queue (CONFIGURABLES): ' . date("Y-m-d H:i:s"));
                $this->_logger->info('---------------------------------------------------');

                $queueData = $this->_queueRepository->getList($filter)->getItems();
                foreach ($queueData as $product) {

                    $configurables = true;

                    if (isset($product['model'])) {

                        if (!@unserialize($product['data'])) {

                            $this->_logger->error('Error on queue product, unserialize error');
                            $this->_logger->error(json_encode($product));

                            $product->setData('process_status', "Error");
                            $product->setData('process_message', "Error on queue product, unserialize error");

                            $resp = $this->_queueRepository->save($product);

                        } else {

                            // Only process verified data
                            $data = unserialize($product['data']);
                            $processObject = $this->_objectManager->get($product['model']);
                            $processObject->{$product['method']}($data);

                            $this->_queueRepository->delete($product);

                            $this->_logger->info('Process product from Queue: ' . $product['process_name']);

                        }

                    } else {

                        $this->_logger->error('Error on queue product');
                        $this->_logger->error(json_encode($product));

                    }

                }

            }

        if(!$configurables && !$grouped){

            // PROCCESS VIRTUALS ITEMS AS THIRD INSTANCE

            $filter = $this->_criteriaBuilder
                ->setPageSize(500)
                ->addFilter('process_status', 'Pending', '=')
                ->addFilter('method', 'create', '=')
                ->create();

            $this->_logger->info('---------------------------------------------------');
            $this->_logger->info('Start process Queue (VIRTUALS): ' . date("Y-m-d H:i:s"));
            $this->_logger->info('---------------------------------------------------');

            $queueData = $this->_queueRepository->getList($filter)->getItems();
            foreach ($queueData as $product) {


                if (isset($product['model'])) {

                    if (!@unserialize($product['data'])) {

                        $this->_logger->error('Error on queue product, unserialize error');
                        $this->_logger->error(json_encode($product));

                        $product->setData('process_status', "Error");
                        $product->setData('process_message', "Error on queue product, unserialize error");

                        $resp = $this->_queueRepository->save($product);

                    } else {

                        // Only process verified data
                        $data = unserialize($product['data']);
                        $processObject = $this->_objectManager->get($product['model']);
                        $processObject->{$product['method']}($data);

                        $this->_queueRepository->delete($product);

                        $this->_logger->info('Process product from Queue: ' . $product['process_name']);

                    }

                } else {

                    $this->_logger->error('Error on queue product');
                    $this->_logger->error(json_encode($product));

                }

            }

        }

            // After all, reindex all products
            //$this->reindexAll();
            $this->_logger->info('---------------------------------------------------');
            $this->_logger->info('Finish process Queue: ' . date("Y-m-d H:i:s"));
            $this->_logger->info('---------------------------------------------------');


        //}else{

        //    $this->_logger->info('Cron disabled on Process Queue');

        //}

        return $this;

    }

    public function reindexAll(){

        // feel free to delete indexers which not require reindexing
        foreach ([
                     'catalog_category_product',
                     'catalog_product_category',
                     'catalog_product_price',
                     'catalog_product_attribute',
                     'cataloginventory_stock',
                     'catalogrule_rule',
                     'catalogrule_product',
                     'catalogsearch_fulltext',

                 ] as $indexerId) {

            $this->indexerFactory->create()
                ->load($indexerId)
                ->reindexAll();

        }

    }

}
