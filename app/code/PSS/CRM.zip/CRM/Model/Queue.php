<?php
/**
 * @author Cristian Sanclemente <csanclemente@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Model;
class Queue extends \Magento\Framework\Model\AbstractModel implements \Alfa9\Base\Api\Data\QueueInterface, \Magento\Framework\DataObject\IdentityInterface
{
    const CACHE_TAG = 'alfa9_queue';

    protected function _construct()
    {
        $this->_init('Alfa9\Base\Model\ResourceModel\Queue');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
