<?php
/**
 *  @author Xavier Sanz <xsanz@pss.com>
 *  @copyright Copyright (c) 2017 PSS (http://www.pss.com)
 *  @package PSS
 */

namespace PSS\CRM\Model\Api;

use Braintree\Exception;
use Magento\Framework\Component\ComponentRegistrarInterface;
use PSS\CRM\Model\Api\AbstractModel;
use Magento\Framework\Stdlib\DateTime;
use Magento\Framework\Exception\InvalidEmailOrPasswordException;

/**
 * Class UserService
 * @package PSS\CRM\Model\Api
 */

class UserService extends AbstractModel
{

    /**
     * @var \PSS\CRM\Helper\UserService
     */
    protected $_helper;

    /**
     * @var
     */
    protected $_wsdl;

    /**
     *
     */
    protected $_logger;

    /**
     * @var \PSS\Customer\Model\Customer
     */

    protected $_customer;


    /**
     * UserService constructor.
     * @param \PSS\CRM\Logger\Logger $logger
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Zend\Soap\Client $soapClient
     * @param ComponentRegistrarInterface $componentRegistrar
     * @param \PSS\CRM\Helper\UserService $helper
     * @param $wsdl
     */

    public function __construct(
        \PSS\CRM\Logger\Logger $logger,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Zend\Soap\Client $soapClient,
        ComponentRegistrarInterface $componentRegistrar,
        \PSS\Customer\Model\Customer $customer,
        \PSS\CRM\Helper\UserService $helper,
        $wsdl
    )
    {
        $this->_customer = $customer;
        $this->_helper = $helper;
        $this->_wsdl = $wsdl;
        $this->_logger = $logger;

        parent::__construct($logger, $soapClient, $componentRegistrar, $transportBuilder);
    }

    public function query($customer = null)
    {
        if($customer) {
            $options = [
                'queryUser' => [
                    'User' => [
                        'ProcessInfo' => [
                            'MessageID' => 'ESHOPP.query.PSS',
                            'Source' => $this->_helper->getPISource(),
                            'OriginSystem' => $this->_helper->getPIOrigin(),
                            'User' => $this->_helper->getPIUser(),
                            'MessageDateTime' => date('Y-m-d\TH:i:s', time()),
                        ],
                        'UserInfo' => [
                            'LogonName' => $customer,
                        ]
                    ]
                ]
            ];

            try {
                $result = $this->call($this->_wsdl, $this->_helper, 'queryUser', $options);
                return $result;
            } catch (\Exception $e) {
                $this->_logger->info('ERROR API REQUEST SERVICE: ' . $e->getMessage());
                $this->_logger->info('TRACE: ' . $e->getTraceAsString());
            }
        }
    }

    public function authentication($customer = null, $password = null)
    {
        if($customer) {
            $options = [
                'authentication' => [
                    'User' => [
                        'ProcessInfo' => [
                            'MessageID' => 'ESHOPP.Auth.PSS',
                            'Source' => $this->_helper->getPISource(),
                            'OriginSystem' => $this->_helper->getPIOrigin(),
                            'User' => $this->_helper->getPIUser(),
                            'MessageDateTime' => date('Y-m-d\TH:i:s', time()),
                        ],
                        'UserInfo' => [
                            'UniqueID' => 'ESHOP.Auth.'.rand(100000000,999999999),
                            'LogonName' => $customer,
                            'Password' => $this->_helper->encryptPassword($password)
                        ]
                    ]
                ]
            ];

            try {

                $xml = $this->call($this->_wsdl, $this->_helper, 'authentication', $options);

                if (is_string($xml)) {
                    $p = new \Magento\Framework\Xml\Parser;
                    $p->loadXML($xml);
                    $result = $p->xmlToArray();
                    return $result['soapenv:Envelope']['SOAP-ENV:Body']['ies:authenticationResponse']['ies:StandardResponse'];
                } else {
                    return null;
                }

            } catch (\Exception $e) {

                $this->_logger->info('ERROR API REQUEST SERVICE: ' . $e->getMessage());
                $this->_logger->info('TRACE: ' . $e->getTraceAsString());
                throw new InvalidEmailOrPasswordException(__('An unexpected error Happened, please contact Us.'));

            }
        }
    }

    public function creationSync(\Magento\Customer\Api\Data\CustomerInterface $customer = null, $password)
    {
        if($customer) {
            $options = [
                'creationUserSync' => [
                    'User' => [
                        'ProcessInfo' => [
                            'MessageID' => 'ESHOPP.createUserSync.PSS',
                            'Source' => $this->_helper->getPISource(),
                            'OriginSystem' => $this->_helper->getPIOrigin(),
                            'User' => $this->_helper->getPIUser(),
                            'MessageDateTime' => date('Y-m-d\TH:i:s', time()),
                        ],
                        'UserInfo' => [
                            'UniqueID' => 'ESHOP.createUserSync.'.$customer->getEmail(),
                            'FirstName' => $customer->getFirstname(),
                            'LastName' => $customer->getLastname(),
                            'SecondSurname' => ($customer->getCustomAttribute($this->_customer::SECOND_LASTNAME))?$customer->getCustomAttribute($this->_customer::SECOND_LASTNAME)->getValue():null,
                            'LogonName' => $customer->getEmail(),
                            'Password' => $this->_helper->encryptPassword($password),
                            'Email' => $customer->getEmail(),
                        ]
                    ]
                ]
            ];

            try {
                $xml = $this->call($this->_wsdl, $this->_helper, 'creationSync', $options);
                if (is_string($xml)) {
                    $p = new \Magento\Framework\Xml\Parser;
                    $p->loadXML($xml);
                    $array = $p->xmlToArray();
                    $result = $array['soapenv:Envelope']['SOAP-ENV:Body']['ies:creationResponseSync']['ies:StandardResponse'];
                    return $result;
                } else {
                    return null;
                }


            } catch (\Exception $e) {
                $this->_logger->info('ERROR API REQUEST SERVICE: ' . $e->getMessage());
                $this->_logger->info('TRACE: ' . $e->getTraceAsString());
            }
        }
    }

    public function deletionSync(\Magento\Customer\Api\Data\CustomerInterface $customer = null)
    {
        if($customer) {
            $options = [
                'deletionUserSync' => [
                    'User' => [
                        'ProcessInfo' => [
                            'MessageID' => 'ESHOPP.deletionUserSync.PSS',
                            'Source' => $this->_helper->getPISource(),
                            'OriginSystem' => $this->_helper->getPIOrigin(),
                            'User' => $this->_helper->getPIUser(),
                            'MessageDateTime' => date('Y-m-d\TH:i:s', time()),
                        ],
                        'UserInfo' => [
                            'UniqueID' => 'ESHOP.deleteUserSync.'.$customer->getEmail(),
                            'LogonName' => $customer->getEmail(),
                        ]
                    ]
                ]
            ];

            try {
                $result = $this->call($this->_wsdl, $this->_helper, 'deletionSync', $options);
                return $result;
            } catch (\Exception $e) {
                $this->_logger->info('ERROR API REQUEST SERVICE: ' . $e->getMessage());
                $this->_logger->info('TRACE: ' . $e->getTraceAsString());
            }
        }
    }

}