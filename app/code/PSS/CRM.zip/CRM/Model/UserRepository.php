<?php
namespace PSS\CRM\Model;

use PSS\CRM\Api\UserRepositoryInterface;
use PSS\CRM\Model\Api\UserService;

class UserRepository implements UserRepositoryInterface
{
    protected $_userFactory;
    protected $_userService;

    public function __construct(
        UserService $userService
    )
    {
        $this->_userService = $userService;
    }

    /**
     * Return if user exists by user email
     *
     * @api
     * @param string $email Customer email
     * @return mixed
     * @throws \Magento\Framework\Exception\LocalizedException
     */

    public function get($email)
    {
        //TODO REALIZAR CONSULTA A CRM
        $xml = $this->_userService->query($email);

        if (is_string($xml)) {
            $p = new \Magento\Framework\Xml\Parser;
            $p->loadXML($xml);
            $array = $p->xmlToArray();
            try {
               return $array['soapenv:Envelope']['SOAP-ENV:Body']['ies:queryUserResponse']['ies:StandardResponse']['ies:ResultID'];
            } catch(\Exception $e) {
               return false;
            }
        }

    }
}
