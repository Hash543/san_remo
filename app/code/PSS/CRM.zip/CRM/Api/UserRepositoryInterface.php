<?php
namespace PSS\CRM\Api;

interface UserRepositoryInterface
{

    /**
     * Returns information by user email
     *
     * @api
     * @param string $email User Email
     * @return mixed
     */
    public function get($email);

}
