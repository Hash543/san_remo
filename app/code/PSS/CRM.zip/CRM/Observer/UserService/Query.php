<?php
/**
 *  @author Xavier Sanz <xsanz@pss.com>
 *  @copyright Copyright (c) 2017 PSS (http://www.pss.com)
 *  @package PSS
 */

namespace PSS\CRM\Observer\UserService;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use PSS\CRM\Model\Api\UserServiceFactory;



class Query implements ObserverInterface
{

    protected $_model;

    public function __construct(
        UserServiceFactory $model
    )
    {
        $this->_model = $model;
    }

    /**
     * Execute Observer
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        //TODO
        //$customer = $observer->getEvent()->getCustomer();
        //exit;
    }
}
