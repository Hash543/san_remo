<?php
/**
 * @copyright (c) 2018. PSS (http://www.pss.com)
 * @author Xavier Sanz <xsanz@pss.com>
 * @package crm
 */

namespace PSS\CRM\Observer\UserService;



use PSS\CRM\Model\Api\ContactService;
use PSS\CRM\Model\Api\RequestService;
use PSS\CRM\Helper\ContactService as ContactHelper;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Exception\InvalidEmailOrPasswordException;
use Magento\Framework\Mail\Template\TransportBuilder;

class Modification implements ObserverInterface
{

    protected $contactService;

    protected $requestService;

    protected $contactHelper;

    protected $transportBuilder;

    public function __construct(
        ContactHelper $contactHelper,
        ContactService $contactService,
        TransportBuilder $transportBuilder,
        RequestService $requestService
    )
    {
        $this->contactHelper = $contactHelper;
        $this->contactService = $contactService;
        $this->requestService = $requestService;
        $this->transportBuilder = $transportBuilder;
    }

    /**
     * @param Observer $observer
     * @throws \Exception
     */


    public function execute(Observer $observer)
    {

        $customer = $observer->getData('customer_data_object');

        $result = $this->contactService->modification($customer);


        if(isset($result['ies:ResultID'])){
            switch($result['ies:ResultID']) {
                case '0':
                    break;
                default:
                    if($this->contactHelper->getDebugEmail()!== null) {

                        foreach (explode(',',$this->contactHelper->getDebugEmail()) as $email) {
                            $transport = $this->transportBuilder->setTemplateIdentifier('crm_error_template')
                                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_ADMINHTML, 'store' => '0'])
                                ->setTemplateVars(
                                    [
                                        'method' => 'modification',
                                        'error_message' => 'There was a problem updating: ' . $customer->getEmail(),
                                        'trace_message' => json_encode($result)
                                    ]
                                )
                                ->setFrom('general')
                                ->addTo($email, 'CRM WS Error Receipt')
                                ->getTransport();
                            $transport->sendMessage();
                        }
                    }
                    throw new InvalidEmailOrPasswordException(__('There was a problem updating your information. Please contact Provider.'));
                    break;
            }

        }


    }
}


