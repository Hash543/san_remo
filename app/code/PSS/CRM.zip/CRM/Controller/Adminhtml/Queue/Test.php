<?php
/**
 * @author Juan Carlos M. <juancarlos.martinez@alfa9.com>
 * @copyright Copyright (c) 2018 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Controller\Adminhtml\Queue;

use Magento\Framework\App\Action\Action;
use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Api\SearchCriteriaBuilder as Criteria;
use Magento\Framework\Api\SortOrderBuilder;
use Alfa9\MDM\Helper\Data;
use Alfa9\Base\Api\QueueRepositoryInterface;

error_reporting(-1);
set_time_limit(0);

class Test extends Action
{
    protected $_logger;
    protected $_scopeConfig;
    protected $_queueRepository;
    protected $_criteriaBuilder;
    protected $_sortOrderBuilder;
    protected $_objectManager;
    protected $_mdmHelper;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        QueueRepositoryInterface $queueRepository,
        Criteria $criteriaBuilder,
        SortOrderBuilder $sortOrderBuilder,
        Data $mdmHelper
    ){
        $this->_logger = $logger;
        $this->_scopeConfig = $scopeConfig;
        $this->_queueRepository = $queueRepository;
        $this->_criteriaBuilder = $criteriaBuilder;
        $this->_sortOrderBuilder = $sortOrderBuilder;
        $this->_mdmHelper = $mdmHelper;
        parent::__construct($context);
    }

    public function execute()
    {


        /*
        $filter = $this->_criteriaBuilder->setPageSize(100);
        $filter = $filter->create();

        $this->_logger->info('---------------------------------------------------');
        $this->_logger->info('Start process Queue by cURL request');
        $this->_logger->info('---------------------------------------------------');

        $queueData = $this->_queueRepository->getList($filter)->getItems();
        foreach ($queueData as $product) {

            $data = unserialize($product['data']);
            $processObject = $this->_objectManager->get(($product['model']));
            $processObject->{$product['method']}($data);
            $this->_queueRepository->delete($product);

            $resp = json_decode(json_encode($data), true);

            $this->_logger->info('Process product from Queue by cURL request:');
            $this->_logger->info($resp);

        }

        $this->_logger->info('---------------------------------------------------');
        $this->_logger->info('Finish process Queue by cURL request');
        $this->_logger->info('---------------------------------------------------');

        return $this;

        */


    }
}