<?php
/**
 * @author Cristian Sanclemente <csanclemente@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Controller\Adminhtml\Queue;

use Magento\Framework\Api\SearchCriteriaBuilder as Criteria;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Framework\ObjectManagerInterface;
use Magento\Indexer\Model\IndexerFactory ;

class MassProcess extends \Magento\Backend\App\Action
{
    protected $resultPageFactory = false;

    protected $queueRepository;

    protected $criteriaBuilder;

    protected $sortOrderBuilder;

    protected $objectManager;

    protected $indexerFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Alfa9\Base\Api\QueueRepositoryInterface $queueRepository,
        Criteria $criteriaBuilder,
        SortOrderBuilder $sortOrderBuilder
        //IndexerFactory $indexerFactory

    ) {
        parent::__construct($context);
        $this->queueRepository = $queueRepository;
        $this->criteriaBuilder = $criteriaBuilder;
        $this->sortOrderBuilder = $sortOrderBuilder;
        //$this->indexerFactory = $indexerFactory;
        $this->objectManager = $context->getObjectManager();
    }

    public function execute()
    {

        set_time_limit(-1);
        error_reporting(-1);

        $resultRedirect = $this->resultRedirectFactory->create();
        $selectedIds = $this->getRequest()->getParam('selected');
        $excludedIds = $this->getRequest()->getParam('excluded');
        $namespace = $this->getRequest()->getParam('namespace');

        if($selectedIds && is_array($selectedIds)){
            /**
             * Picked selected items
             */
            $filter = $this->criteriaBuilder
                ->addFilter('alfa9_base_queue_id', $selectedIds, 'in')
                ->create();

        }else if ($excludedIds && is_array($excludedIds)){

            /**
             * All except exclude items
             */
            $filter = $this->criteriaBuilder
                ->addFilter('alfa9_base_queue_id', $excludedIds, 'nin')
                ->create();

        }else{

            /**
             * All records to process
             */
            $filter = $this->criteriaBuilder->create();

        }



        $queueData = $this->queueRepository->getList($filter)->getItems();
        try {
            foreach ($queueData as $product) {
                if($product['process_status']=='Pending') {
                    $processObject = $this->objectManager->get(($product['model']));
                    $processObject->{$product['method']}(unserialize($product['data']));
                    $this->queueRepository->delete($product);
                }
            }

            //$this->reindexAll();
            $this->messageManager->addSuccess(__('The process has been finished successfully, processed %1 record(s).', count($queueData)));
            $resultRedirect->setPath('alfa9/queue/grid');
            return $resultRedirect;
        }
        catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }

        $resultRedirect->setPath('alfa9/queue/grid');
        return $resultRedirect;
    }

    public function reindexAll(){

        // feel free to delete indexers which not require reindexing
        foreach ([
                     'catalog_category_product',
                     'catalog_product_category',
                     'catalog_product_price',
                     'catalog_product_attribute',
                     'cataloginventory_stock',
                     'catalogrule_rule',
                     'catalogrule_product',
                     'catalogsearch_fulltext',

                 ] as $indexerId) {

            /*
            $this->indexerFactory->create()
                ->load($indexerId)
                ->reindexAll();
            */
            $indexer = $this->_objectManager->get('Magento\Framework\Indexer\IndexerRegistry')->get($indexerId);
            $indexer->reindexAll();

        }

    }

}