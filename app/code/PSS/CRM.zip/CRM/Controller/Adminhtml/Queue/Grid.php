<?php
/**
 * @author Cristian Sanclemente <csanclemente@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Controller\Adminhtml\Queue;

use Magento\Framework\Api\SearchCriteriaBuilder;

class Grid extends \Magento\Backend\App\Action
{
    protected $resultPageFactory = false;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Alfa9_Base::extensions');
        $resultPage->addBreadcrumb(__('Alfa9'), __('Alfa9'));
        $resultPage->addBreadcrumb(__('Queue'), __('Queue'));
        $resultPage->getConfig()->getTitle()->prepend(__('Alfa9 Extensions - Process Queue Items'));
        return $resultPage;
    }
}