<?php
/**
 * @author Cristian Sanclemente <csanclemente@alfa9.com>
 * @copyright Copyright (c) 2017 Alfa9 (http://www.alfa9.com)
 * @package Alfa9
 */

namespace Alfa9\Base\Controller\Adminhtml\Queue;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Alfa9\Base\Cron\Queue\ProcessById as ProcessQueue;

class Process extends \Magento\Backend\App\Action
{
    protected $resultPageFactory = false;

    protected $queueProcess;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        ProcessQueue $queueProcess
    ) {
        $this->queueProcess = $queueProcess;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $this->queueProcess->execute($this->getRequest()->getParam('alfa9_base_queue_id'));
        $this->messageManager->addSuccess(__('The process has been finished successfully.'));
        $resultRedirect->setPath('alfa9/queue/grid');
        return $resultRedirect;
    }
}